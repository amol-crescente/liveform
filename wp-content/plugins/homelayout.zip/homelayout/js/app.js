var appHomeLayout = angular.module('appHomeLayout', []);

appHomeLayout.controller('HomeLayout_Ctrl', function($scope) {


});
